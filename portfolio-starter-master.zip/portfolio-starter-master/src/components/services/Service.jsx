import React from "react";
import "./services.css";
import Humble from "../../img/humble.png";
import HeartEmoji from "../../img/heartemoji.png";
import Card from "../card/Card";
import Glasses from "../../img/glasses.png";
import Resume from "./resume.pdf";
const Service = () => {
  return (
    <div className="services">
      <div className="awesome">
        <span>My awesome</span>
        <span>services</span>
        <span>
          Lorem ipsum is simpley dummy text of printing of printing Lorem
          <br />
          ispum is simpley dummy text of printing
        </span>
        <a href={Resume} download>
          <button className="button s-button">Download CV</button>
        </a>
      </div>
      <div className="cards">
        <div style={{ left: "20rem" }}>
          <Card
            emoji={HeartEmoji}
            heading={"Design"}
            detail={"Figma, Sketch, PhotoShop, Adobe"}
          />
        </div>
        <div style={{ top: "12rem", left: "1rem" }}>
          <Card
            emoji={Glasses}
            heading={"Developer"}
            detail={"Html, CSS, JavScript, React"}
          />
        </div>
        <div style={{ top: "19rem", left: "17rem" }}>
          <Card
            emoji={Humble}
            heading={"UI/UX"}
            detail={"Lorem ispum dummy text are usally use in sectionn ehere "}
          />
        </div>
      </div>
    </div>
  );
};

export default Service;
