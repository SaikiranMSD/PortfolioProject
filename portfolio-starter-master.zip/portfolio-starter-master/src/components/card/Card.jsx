import React from "react";
import "./card.css";
const Card = (props) => {
  return (
    <div className="card">
      <img src={props.emoji} alt="" />
      <span>{props.heading}</span>
      <span style={{ textAlign: "center" }}>{props.detail}</span>
      <button className="button">Learn more</button>
    </div>
  );
};

export default Card;
