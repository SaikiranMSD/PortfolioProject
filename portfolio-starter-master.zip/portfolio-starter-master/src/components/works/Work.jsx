import React from "react";
import "./works.css";
import upwork from "../../img/Upwork.png";
import fiverr from "../../img/fiverr.png";
import amazon from "../../img/amazon.png";
import fb from "../../img/Facebook.png";
import shopify from "../../img/Shopify.png";
const Work = () => {
  return (
    <div className="works">
      <div className="awesome">
        <span>Works for All these</span>
        <span>Brands & Clinets</span>
        <span>
          Lorem ipsum is simpley dummy text of printing of printing Lorem
          <br />
          Lorem ipsum is simpley dummy text of printing of printing Lorem
          <br />
          Lorem ipsum is simpley dummy text of printing of printing Lorem
          <br />
          ispum is simpley dummy text of printing
        </span>

        <button className="button s-button">Hire Me</button>
      </div>
      <div className="w-right">
        <div className="w-main-circle">
          <div className="w-sec-circle">
            <img src={upwork} alt="" />
          </div>
          <div className="w-sec-circle">
            <img src={fiverr} alt="" />
          </div>
          <div className="w-sec-circle">
            <img src={amazon} alt="" />
          </div>
          <div className="w-sec-circle">
            <img src={fb} alt="" />
          </div>
          <div className="w-sec-circle">
            <img src={shopify} alt="" />
          </div>
        </div>
        <div className="backcircle bluecircle"></div>
        <div className="backcircle yellowcircle"></div>
      </div>
    </div>
  );
};

export default Work;
